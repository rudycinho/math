# Ejemplos Y Contraejemplos

Problema. 
Demuestre que los numeros del 1 al 16 pueden disponerse, en una línea recta de manera que la suma de cada par de numeros consecutivos sea cuadrado perfecto.

Solucion.

- Comprender Problema
![[Pasted image 20250225224443.png]]

- Los cuadrados perfectos que existen entre 1 al 16 al sumar
$$
\begin{aligned}
4 &\qquad 9 &\qquad 16 &\qquad 25\\
2^2 &\qquad 3^2 &\qquad 4^2 &\qquad 5^2\\
\end{aligned}
$$
$$
\begin{align}
1+3=4
\end{align}
$$

$$
\begin{align}
1+8=9 \\2+7=9 \\3+6=9 \\4+5=9
\end{align}
$$
$$
\begin{align}
1+15=16\\2+14=16\\3+13=16\\4+12=16\\5+11=16\\6+10=16\\7+9=16
\end{align}
$$
$$
\begin{align}
9+16=25\\10+15=25\\11+14=25\\12+13=25\\
\end{align}
$$

![[Pasted image 20250225230306.png]]
$\blacksquare$


Problema 2.
En la cuadricula siguiente estan escritos todos los enteros del 1 al 25. Considere todos los conjuntos formador por cinco de estos numeros, de manera que en cada conjunto no haya dos numeros que esten en la misma fila ni en la misma columna.


a. Encuentre un conjunto de cinco numeros que cumple la condicion dada, en el cual el mayor elemento sea 23

El conjunto : $\{23,7,21,19,3\} \qquad \blacksquare$

b. Encuentre un conjunto de cinco numeros que cumplen la condicion dada, en le que el numero mas grande sea lo mas pequenio posible.

La respuesta es $11$, $\{11,3,1,6,8\}$
Por la demostracion procedemos por contradiccion.

Problema 3 
Un numero "n" se considera azul, si la suma de sus digitos es igual a la suma de sus digitos $\boxed{3n+11}$ . Demuestre que existen infinitos numeros azules.

Solucion 
$n=17$ es azul. (Suma de digitos de 17 es 8)
$3n+11 = 3\cdot17+11 = 62$ 

$$
\begin{align}
n=107 &\Rightarrow 3\cdot n+11 = 3\cdot107 + 11 = 332\\
n=1007 &\Rightarrow 3\cdot n+11 = 3\cdot1007 + 11 = 3032\\
n=10007 &\Rightarrow 3\cdot n+11 = 3\cdot10007 + 11 = 30032\\
n=100007 &\Rightarrow 3\cdot n+11 = 3\cdot100007 + 11 = 300032\\
\end{align}
$$

Asi sucesicamente, si aplicamos el metodo de inducción sobre el numero ceros ("n")
$$
	3\cdot 1\underbrace{0000\dots 0}_{\text{n-ceros}}7 \,+ 11 = 3\underbrace{000\dots0}_{(n-1) \text{ceros}}32
$$


$\forall n \in N$. Y esto significa que existen infinitos numero azules $\blacksquare$


3.100007+11-900032

ΑΝΟΒΙΕΡΓΑ Τη

pu considina

diguten es quel Bn+11. Demvedre anofer.

adito quinam

YrEIN, Y esto significa que existen efinitor namne azaler PROBLEMA xouble destilser todo in namun all so in lon pailles de in biceno 546, 0 por cada, 1 qu

Todas by columisan, tomos la navee Sard

chuon not in and

are or digitos de 12 as 8)

3462


332

+11=3032

+11=300031

elado de inducción sobre

30200032

infinito nemné azuler

Mods in dil t por orala, diwassa a

15

1430465 and

pronte at lo más pequeña pore

rapuel (4,2,1,6,8)

0=107 30+11=2-107+1=332

6=1007

des sucesivamente, si aplicamor el metodo de inducción sobre

31000 07+11=000082

azar se la suma de son diaiden is qual a the same de los digiters In+19. Demantre que existen intierter names ageter.

Shape 17 es aged (sama se digiós te te as by 311-34-1-62

tre. Y ade significa que existen infinitos rúmne azulen 200.000 + exale disrieur tots los temve tel tod so in tou prastos de un riskera 346, no rex mala, de manera με Tade branlerces, tergen la misma soms

