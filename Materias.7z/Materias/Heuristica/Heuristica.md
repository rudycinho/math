[[Principio de Contradiccion]]
[[Induccion]]
[[Identificando Patrones]]

